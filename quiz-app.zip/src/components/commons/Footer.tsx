import React from 'react'

const Footer = () => {
    return (
        <footer className='flex w-full'>
            
        </footer>
    )
}

export default Footer